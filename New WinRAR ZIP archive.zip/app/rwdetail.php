<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class rwdetail extends Model
{
    protected $table = 'rwdetail';
}
