<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ruang extends Model
{
    protected $table = 'ruang';
}
