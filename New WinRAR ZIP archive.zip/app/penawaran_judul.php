<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class penawaran_judul extends Model
{
    //
}
