<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class semprojadwal extends Model
{
    protected $table = 'semprojadwal';
}
