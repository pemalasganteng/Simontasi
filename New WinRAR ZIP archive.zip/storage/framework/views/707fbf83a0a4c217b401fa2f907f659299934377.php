<?php $__env->startSection('content'); ?>
<div class="col-12 mt-5">
                                <div class="card">
                                    <div class="card-body">
                                        <?php if($errors->any()): ?>
                                            <div class="alert alert-danger">
                                                <ul>
                                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        <?php endif; ?>
                                         <?php if(session('sukses')): ?>
                        <div class="alert alert-success"><?php echo e(session('sukses')); ?></div>
                    <?php endif; ?>
                                        <h4 class="header-title">Penjadwalan Sempro</h4>
                                        <p class="text-muted font-14 mb-4">Silahkan menggunakan aplikasi ini sebaik-baiknya.
Jika Anda mengalami kesulitan, silahkan hubungi <code>Administrator</code>.</p>
                                    <form action="<?php echo e(route('penjadwalansempro_post')); ?>" method="POST" enctype="multipart/form-data">>
                                        <?php echo e(csrf_field()); ?>

                                       <fieldset disabled="">
                                        <div class="form-group">
                                                    <label for="disabledTextInput">Nama</label>
                                                    <input type="text" id="disabledTextInput" class="form-control" placeholder="<?php echo e($data[0]->nameMhs.' - ' . $data[0]->nimMhs); ?>">
                                                </div>
                                        <div class="form-group">
                                                    <label for="disabledTextInput">Judul Proposal</label>
                                                    <input type="text" id="disabledTextInput" class="form-control" placeholder="<?php echo e($data[0]->judul); ?>">
                                                </div> 
                                        <div class="form-group">
                                                    <label for="disabledTextInput">Pembimbing</label>
                                                    <input type="text" id="disabledTextInput" class="form-control" placeholder="<?php echo e($data[0]->nameDosen); ?>">
                                                </div>                                            
                                        </fieldset>
                                        <div class="form-group">
                                            <label class="col-form-label">Dosen Penguji 1</label>
                                            <select name="penguji1" class="custom-select">
                                                <option  selected="selected">Pilih Dosen</option>
                                                <?php $__currentLoopData = $dosenpenguji; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($d->id); ?>"><?php echo e($d->name . ' - ' . $d->nim); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label">Dosen Penguji 2</label>
                                            <select name="penguji2" class="custom-select">
                                                <option selected="selected">Pilih Dosen</option>
                                                <?php $__currentLoopData = $dosenpenguji; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($d->id); ?>"><?php echo e($d->name . ' - ' . $d->nim); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>       
                                        <div class="form-group">
                                            <label for="example-date-input" class="col-form-label">Tanggal</label>
                                            <input class="form-control" type="date" name="tanggal" id="example-date-input">
                                        </div>
                                        
                                        <div class="form-group">
                                            <label class="col-form-label">Pilih Ruang dan Waktu</label>
                                            <select name="ruang" class="custom-select">
                                                <option selected="selected">Open this select menu</option>
                                                <?php $__currentLoopData = $ruang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($r->ruangId); ?>|<?php echo e($r->waktuId); ?>"><?php echo e($r->nama_ruang .' - Sesi '. $r->sesi . ' - ' .$r->jam_mulai . ' - ' . $r->jam_akhir); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        
                                        <input type="hidden" name="id_user" value="<?php echo e($data[0]->idMhs); ?>">
                                        <input type="hidden" name="id_proposalsempro" value="<?php echo e($data[0]->idProposalsempro); ?>">

                                        </div>
                                    <div class="form-group" style="float: right;">    
                                      <button type="submit" class="btn btn-rounded btn-success mb-3">Jadwalkan</button>  
                                    </div> 

                                    </form>
                                    </div>
                                </div>
                            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sisfotasi2\resources\views/kaprodi/jadwalkansempro.blade.php ENDPATH**/ ?>